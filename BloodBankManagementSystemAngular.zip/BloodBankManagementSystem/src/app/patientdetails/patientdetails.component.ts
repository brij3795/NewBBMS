import { Component, OnInit, Input } from '@angular/core';
import { Patient } from '../model/patientdetails';
import { ServiceService } from '../service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-patientdetails',
  templateUrl: './patientdetails.component.html',
  styleUrls: ['./patientdetails.component.css']
})
export class PatientdetailsComponent implements OnInit {

  patientdetailsArr: Patient[] = [];
  patientArr: Patient[] = [];
  allEmailId: [];
  trial: any;
  emailCheck: boolean;
  patient: any;
  paramIndex: any;
  maxDate: Date;

  constructor(private service: ServiceService, private router: Router, private route: ActivatedRoute) {
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());

    this.patient = new Patient();
    this.load();

  }


  ngOnInit() {


  }
  validateAction() {
    if (window.location.search !== '') {
      this.route.queryParams.pipe()
        .subscribe(params => {
          console.log('update');
          this.updatePatient();
        });
    } else {
      console.log('add');
      this.addPatient();
    }
  }


  updatePatient() {
    this.service.updatePatient(this.patient.id, this.patient).subscribe(
      data => {
        console.log(data);
        alert('Patient details saved successfully.')
      },
      error => {
        console.log(error);
      },
      () => { // when complete
        this.router.navigate(['/admin']);
      });

  }

  addPatient() {
    this.service.addPatient(this.patient).subscribe(
      data => {
        console.log(data);

        this.router.navigate(['/admin']);

      });
  }

  load() {
    if (window.location.search !== '') {
      this.route.queryParams.pipe(
        filter(params => params.id))
        .subscribe(params => {
          console.log(params.id);
          this.paramIndex = params.id;
          this.service.getPatientById(this.paramIndex).subscribe(res => {
            this.patient = res;
            console.log(this.patient)
          });
        });

    }
  }



  getPatients() {
    this.service.getPatient().subscribe(res => {
      this.patientArr = res;
      if (this.patientArr.length === 0) {
        this.addPatient();
        this.router.navigate(['/admin']);
      }

      for (const u of this.patientArr) {

        if (this.patient.patientEmail !== u.patientEmail) {
          this.emailCheck = true;
        }
        else {
          this.emailCheck = false;
          alert('patient id  already exists');
          break;
        }
      }
      if (this.emailCheck) {
        this.addPatient();
        this.router.navigate(['/admin']);
      }

    });
  }


}
