import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { User } from '../model/user';

@Component({
  selector: 'app-viewuser',
  templateUrl: './viewuser.component.html',
  styleUrls: ['./viewuser.component.css']
})
export class ViewuserComponent implements OnInit {


  userArr: User[] = [];
  user: User;
  constructor(private service: ServiceService) {
  }

  ngOnInit() {
    this.getUserByEmail();
  }

  getUserByEmail() {
    this.service.getUserByEmail(sessionStorage.getItem('useremail')).subscribe(res => {
      this.user = res;
      JSON.stringify(this.user);
      console.log(this.user);
    });
  }

 

}
